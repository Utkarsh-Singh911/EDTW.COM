
import React, { useState } from 'react';
import { textToNums, hillProcess, matrixInverse, Matrix } from '../lib/hillCipher';
import OutputDisplay, { OutputLine } from './OutputDisplay';

const DecryptSection: React.FC = () => {
    const [cipherText, setCipherText] = useState('');
    const [key, setKey] = useState('');
    const [output, setOutput] = useState<OutputLine[]>([]);
    const [error, setError] = useState<string | null>(null);

    const handleDecrypt = () => {
        setError(null);
        setOutput([]);
        
        if (!cipherText.trim() || !key.trim()) {
            setError("Please enter ciphertext and key.");
            return;
        }

        const parts = key.split(',').map(s => parseInt(s.trim(), 10));
        if (parts.length !== 4 || parts.some(isNaN)) {
            setError("Invalid key format. Enter key as a,b,c,d.");
            return;
        }

        const keyMatrix: Matrix = [[parts[0], parts[1]], [parts[2], parts[3]]];
        const inverseMatrix = matrixInverse(keyMatrix);

        if (!inverseMatrix) {
            setError("Key not invertible (Determinant not coprime with 27).");
            return;
        }

        if (cipherText.replace(/[^A-Z ]/ig, '').length % 2 !== 0) {
            setError("Ciphertext length must be even for a 2x2 Hill Cipher.");
            return;
        }

        const nums = textToNums(cipherText);
        const decrypted = hillProcess(nums, inverseMatrix);
        
        setOutput([{ id: 'decryptedText', label: 'Decrypted', value: decrypted }]);
    };

    return (
        <div className="w-full p-6 rounded-2xl bg-white shadow-lg mb-8 animate-fade-in">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Decrypt Message</h3>
            <textarea
                value={cipherText}
                onChange={(e) => setCipherText(e.target.value)}
                placeholder="ENTER TEXT"
                className="w-full h-24 my-2.5 rounded-xl border border-gray-300 p-3 text-base outline-none bg-gray-50 text-gray-800 uppercase resize-y focus:border-orange-500 focus:ring-2 focus:ring-orange-500/50 transition-colors"
            />
            <input
                value={key}
                onChange={(e) => setKey(e.target.value)}
                placeholder="Enter 4-digit key (a,b,c,d)"
                className="w-full my-2.5 rounded-xl border border-gray-300 p-3 text-base outline-none bg-gray-50 text-gray-800 uppercase focus:border-orange-500 focus:ring-2 focus:ring-orange-500/50 transition-colors"
            />
            <button
                onClick={handleDecrypt}
                className="w-full bg-orange-500 border-none py-2.5 px-6 text-lg rounded-full text-white font-semibold cursor-pointer shadow-[0_0_10px_rgba(255,140,0,0.5),_0_0_20px_rgba(255,140,0,0.3)] transition-transform duration-300 hover:scale-105 hover:shadow-[0_0_15px_rgba(255,140,0,0.7),_0_0_30px_rgba(255,140,0,0.5)] mt-2.5"
            >
                Decrypt
            </button>
            <OutputDisplay outputs={output} error={error} defaultMessage="Decrypted text will appear here..." />
        </div>
    );
};

export default DecryptSection;
