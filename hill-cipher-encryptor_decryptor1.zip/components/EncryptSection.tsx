
import React, { useState } from 'react';
import { prepareText, hillProcess, gcd, Matrix } from '../lib/hillCipher';
import OutputDisplay, { OutputLine } from './OutputDisplay';

const EncryptSection: React.FC = () => {
    const [plainText, setPlainText] = useState('');
    const [manualKey, setManualKey] = useState('');
    const [hasKey, setHasKey] = useState(false);
    const [output, setOutput] = useState<OutputLine[]>([]);
    const [error, setError] = useState<string | null>(null);

    const handleEncrypt = () => {
        setError(null);
        setOutput([]);

        if (!plainText.trim()) {
            setError("Please enter text to encrypt.");
            return;
        }

        let keyMatrix: Matrix | null = null;

        if (hasKey) {
            const parts = manualKey.split(',').map(s => parseInt(s.trim(), 10));
            if (parts.length !== 4 || parts.some(isNaN) || parts.some(p => p < 0 || p > 26)) {
                setError("Invalid key. Enter 4 numbers (0-26) separated by commas.");
                return;
            }
            const testMatrix: Matrix = [[parts[0], parts[1]], [parts[2], parts[3]]];
            const det = (testMatrix[0][0] * testMatrix[1][1] - testMatrix[0][1] * testMatrix[1][0]);
            const detMod = (det % 27 + 27) % 27;

            if (gcd(detMod, 27) !== 1) {
                setError(`Key determinant (${detMod}) is not coprime with 27. Choose another key.`);
                return;
            }
            keyMatrix = testMatrix;
        } else {
            while (true) {
                const a = Math.floor(Math.random() * 27);
                const b = Math.floor(Math.random() * 27);
                const c = Math.floor(Math.random() * 27);
                const d = Math.floor(Math.random() * 27);
                const det = (a * d - b * c);
                const detMod = (det % 27 + 27) % 27;
                if (gcd(detMod, 27) === 1) {
                    keyMatrix = [[a, b], [c, d]];
                    break;
                }
            }
        }

        const { nums, isPadded } = prepareText(plainText);
        const encrypted = hillProcess(nums, keyMatrix);
        const keyStr = `${keyMatrix[0][0]},${keyMatrix[0][1]},${keyMatrix[1][0]},${keyMatrix[1][1]}`;

        const newOutput: OutputLine[] = [
            { id: 'encryptedText', label: `Encrypted (Length ${encrypted.length})`, value: encrypted },
            { id: 'key', label: 'Key', value: keyStr }
        ];

        if (isPadded) {
            newOutput.push({ id: 'paddingInfo', label: 'Info', value: '(Padded with a space for block processing.)', isInfo: true });
        }

        setOutput(newOutput);
    };

    return (
        <div className="w-full p-6 rounded-2xl bg-white shadow-lg mb-8 animate-fade-in">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Encrypt Message</h3>
            <textarea
                value={plainText}
                onChange={(e) => setPlainText(e.target.value)}
                placeholder="ENTER TEXT"
                className="w-full h-24 my-2.5 rounded-xl border border-gray-300 p-3 text-base outline-none bg-gray-50 text-gray-800 uppercase resize-y focus:border-orange-500 focus:ring-2 focus:ring-orange-500/50 transition-colors"
            />
            <div className="flex items-center justify-between my-4">
                <label htmlFor="hasKeySwitch" className="font-semibold text-gray-700">
                    Have a key?
                </label>
                <label className="relative inline-block w-[45px] h-[25px]">
                    <input
                        type="checkbox"
                        id="hasKeySwitch"
                        checked={hasKey}
                        onChange={(e) => {
                            setHasKey(e.target.checked);
                            setOutput([]);
                            setError(null);
                        }}
                        className="opacity-0 w-0 h-0"
                    />
                    <span className="absolute cursor-pointer top-0 left-0 right-0 bottom-0 bg-gray-300 rounded-full transition-all duration-300 before:content-[''] before:absolute before:h-[17px] before:w-[17px] before:left-1 before:bottom-1 before:bg-white before:rounded-full before:transition-all before:duration-300 peer-checked:bg-orange-500 peer-checked:before:translate-x-5"></span>
                </label>
            </div>
            {hasKey && (
                <input
                    value={manualKey}
                    onChange={(e) => setManualKey(e.target.value)}
                    placeholder="Enter 4-digit key (a,b,c,d)"
                    className="w-full my-2.5 rounded-xl border border-gray-300 p-3 text-base outline-none bg-gray-50 text-gray-800 uppercase focus:border-orange-500 focus:ring-2 focus:ring-orange-500/50 transition-colors"
                />
            )}
            <button
                onClick={handleEncrypt}
                className="w-full bg-orange-500 border-none py-2.5 px-6 text-lg rounded-full text-white font-semibold cursor-pointer shadow-[0_0_10px_rgba(255,140,0,0.5),_0_0_20px_rgba(255,140,0,0.3)] transition-transform duration-300 hover:scale-105 hover:shadow-[0_0_15px_rgba(255,140,0,0.7),_0_0_30px_rgba(255,140,0,0.5)] mt-2.5"
            >
                Encrypt
            </button>
            <OutputDisplay outputs={output} error={error} defaultMessage="Encrypted text & key will appear here..." />
        </div>
    );
};

export default EncryptSection;
