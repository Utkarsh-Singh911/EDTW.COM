
import React, { useState } from 'react';
import CopyIcon from './icons/CopyIcon';

export interface OutputLine {
    id: string;
    label: string;
    value: string;
    isInfo?: boolean;
}

interface OutputDisplayProps {
    outputs: OutputLine[];
    error: string | null;
    defaultMessage: string;
}

const OutputDisplay: React.FC<OutputDisplayProps> = ({ outputs, error, defaultMessage }) => {
    const [copyStatus, setCopyStatus] = useState<Record<string, string>>({});

    const handleCopy = async (text: string, id: string) => {
        try {
            await navigator.clipboard.writeText(text);
            setCopyStatus({ ...copyStatus, [id]: 'Copied!' });
        } catch (err) {
            setCopyStatus({ ...copyStatus, [id]: 'Failed!' });
        }
        setTimeout(() => setCopyStatus({ ...copyStatus, [id]: '' }), 2000);
    };

    if (error) {
        return (
            <div className="mt-4 bg-gray-100 p-4 rounded-xl shadow-inner w-full text-left text-red-600 font-semibold break-words">
                {error}
            </div>
        );
    }

    if (outputs.length === 0) {
        return (
            <div className="mt-4 bg-gray-100 p-4 rounded-xl shadow-inner w-full text-left text-gray-500 italic break-words">
                {defaultMessage}
            </div>
        );
    }

    return (
        <div className="mt-4 bg-gray-100 p-4 rounded-xl shadow-inner w-full text-left text-gray-800 space-y-2">
            {outputs.map(output => (
                 output.isInfo ? (
                    <div key={output.id} className="text-sm text-orange-600 font-semibold">
                        {output.value}
                    </div>
                 ) : (
                    <div key={output.id} className="flex justify-between items-center gap-2">
                        <div className="flex-grow break-all">
                            <b className="mr-2">{output.label}:</b>
                            <span>{output.value}</span>
                        </div>
                        <div className="flex items-center">
                             {copyStatus[output.id] && (
                                <span className="text-sm text-orange-600 font-bold mr-2 transition-opacity duration-300">
                                    {copyStatus[output.id]}
                                </span>
                            )}
                            <button onClick={() => handleCopy(output.value, output.id)} className="p-1 rounded-md hover:bg-gray-300/50 transition-colors">
                                <CopyIcon className="w-4 h-4 text-gray-600" />
                            </button>
                        </div>
                    </div>
                 )
            ))}
        </div>
    );
};

export default OutputDisplay;
