
export type Matrix = [[number, number], [number, number]];

// Character map: A=0,...,Z=25, space=26
export const charToNum = (c: string): number => (c === ' ' ? 26 : c.charCodeAt(0) - 65);
export const numToChar = (n: number): string => (n === 26 ? ' ' : String.fromCharCode(n + 65));

export const textToNums = (text: string): number[] => {
  return text.toUpperCase().split('').filter(ch => /[A-Z ]/.test(ch)).map(charToNum);
};

export const numsToText = (nums: number[]): string => {
  return nums.map(numToChar).join('');
};

export const prepareText = (text: string): { nums: number[], isPadded: boolean } => {
    let nums = textToNums(text);
    let isPadded = nums.length % 2 !== 0;
    if (isPadded) {
        nums.push(26); // Pad with space (26)
    }
    return { nums, isPadded };
};

export const hillProcess = (nums: number[], M: Matrix): string => {
  let result: number[] = [];
  for (let i = 0; i < nums.length; i += 2) {
    result.push(
      (M[0][0] * nums[i] + M[0][1] * nums[i+1]) % 27,
      (M[1][0] * nums[i] + M[1][1] * nums[i+1]) % 27
    );
  }
  return numsToText(result);
};

export const gcd = (a: number, b: number): number => {
    while (b) {
        [a, b] = [b, a % b];
    }
    return a;
};

export const modInverse = (a: number, m: number = 27): number | null => {
  a = (a % m + m) % m;
  for (let x = 1; x < m; x++) if ((a * x) % m === 1) return x;
  return null;
};

export const matrixInverse = (M: Matrix): Matrix | null => {
  let det = (M[0][0] * M[1][1] - M[0][1] * M[1][0]);
  let detMod = (det % 27 + 27) % 27;
  let detInv = modInverse(detMod);
  if (!detInv) return null;

  const a = ( M[1][1] * detInv);
  const b = (-M[0][1] * detInv);
  const c = (-M[1][0] * detInv);
  const d = ( M[0][0] * detInv);

  return [
    [(a % 27 + 27) % 27, (b % 27 + 27) % 27],
    [(c % 27 + 27) % 27, (d % 27 + 27) % 27]
  ];
};
